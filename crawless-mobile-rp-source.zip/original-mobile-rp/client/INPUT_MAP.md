# Input mapping
In Godot Editor open **Project → Project Settings → Input Map** and add:
- `move_left`: A, Left
- `move_right`: D, Right
- `move_forward`: W, Up
- `move_back`: S, Down

Android touch buttons are created by the HUD. The production input pass should add a proper virtual joystick, camera drag, dead zones, accessibility sizing and device-specific tuning.
