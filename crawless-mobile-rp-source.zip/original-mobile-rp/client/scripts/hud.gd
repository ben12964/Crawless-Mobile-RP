extends CanvasLayer
## Mobile-first HUD shell; gameplay actions are buttons, not slash-command chat.
var status_label: Label
var joystick: TouchScreenButton

func _ready() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)
    status_label = Label.new()
    status_label.text = "ORIGINAL RP  •  Connecting..."
    status_label.position = Vector2(24, 18)
    status_label.add_theme_font_size_override("font_size", 22)
    root.add_child(status_label)
    _button(root, "INTERACT", Vector2(-190, -150), Vector2(150, 64), _interact)
    _button(root, "INVENTORY", Vector2(-190, -78), Vector2(150, 58), _inventory)
    _button(root, "PHONE", Vector2(-190, -12), Vector2(150, 58), _phone)
    var help := Label.new()
    help.text = "Touch controls • Walk around the city"
    help.position = Vector2(24, 56)
    root.add_child(help)
    _position_right_buttons(root)
    get_viewport().size_changed.connect(func(): _position_right_buttons(root))

func _button(root: Control, title: String, offset: Vector2, size: Vector2, action: Callable) -> void:
    var b := Button.new()
    b.text = title
    b.size = size
    b.anchor_left = 1.0
    b.anchor_right = 1.0
    b.anchor_top = 1.0
    b.anchor_bottom = 1.0
    b.position = offset
    b.add_theme_font_size_override("font_size", 18)
    b.pressed.connect(action)
    root.add_child(b)

func _position_right_buttons(root: Control) -> void:
    for node in root.get_children():
        if node is Button:
            node.position.y = -150 if node.text == "INTERACT" else (-78 if node.text == "INVENTORY" else -12)

func _interact() -> void:
    _show_message("Interaction menu: Talk • Trade • Inspect • Report")

func _inventory() -> void:
    _show_message("Inventory UI: persistent items load from your character state")

func _phone() -> void:
    _show_message("Phone UI: Contacts • Banking • Jobs • Emergency")

func _show_message(message: String) -> void:
    status_label.text = "ORIGINAL RP  •  " + message
