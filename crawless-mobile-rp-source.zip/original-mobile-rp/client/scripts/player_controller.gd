extends CharacterBody3D
## Third-person movement with keyboard support for editor and touch joystick for Android.
@export var speed := 5.5
@export var acceleration := 18.0
@export var gravity := 18.0
var touch_direction := Vector2.ZERO
var camera_pivot: Node3D

func _ready() -> void:
    camera_pivot = get_node_or_null("CameraPivot")

func _physics_process(delta: float) -> void:
    var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    if touch_direction.length() > 0.05:
        input_dir = touch_direction
    var direction := Vector3(input_dir.x, 0, input_dir.y)
    if camera_pivot:
        direction = camera_pivot.global_basis * direction
        direction.y = 0
    direction = direction.normalized()
    velocity.x = move_toward(velocity.x, direction.x * speed, acceleration * delta)
    velocity.z = move_toward(velocity.z, direction.z * speed, acceleration * delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0
    move_and_slide()

func set_touch_direction(value: Vector2) -> void:
    touch_direction = value.limit_length(1.0)
