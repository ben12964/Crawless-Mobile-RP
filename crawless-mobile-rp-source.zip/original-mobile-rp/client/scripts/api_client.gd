extends Node
class_name ApiClient
## Set base_url to your deployed HTTPS API endpoint.
var base_url := "http://127.0.0.1:8000"
var access_token := ""
var http: HTTPRequest

func _ready() -> void:
    http = HTTPRequest.new()
    add_child(http)

func request_json(path: String, method: int, payload: Dictionary = {}) -> Dictionary:
    var headers := PackedStringArray(["Content-Type: application/json"])
    if not access_token.is_empty():
        headers.append("Authorization: Bearer " + access_token)
    var body := JSON.stringify(payload) if not payload.is_empty() else ""
    var err := http.request(base_url + path, headers, method, body)
    if err != OK:
        return {"ok": false, "error": "Could not start request"}
    var result = await http.request_completed
    var code: int = result[1]
    var parsed = JSON.parse_string(result[3].get_string_from_utf8())
    return {"ok": code >= 200 and code < 300, "status": code, "data": parsed}
