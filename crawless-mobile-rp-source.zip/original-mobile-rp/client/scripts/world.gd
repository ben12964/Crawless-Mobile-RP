extends Node3D
## Procedural greybox city blocks to validate scale and mobile rendering.
## Replace/extend with original authored meshes, materials, roads and interiors.

func _ready() -> void:
    _build_ground()
    _build_city_blocks()
    _build_road()

func _material(color: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.9
    return m

func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> void:
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.position = pos
    mesh_instance.material_override = mat
    parent.add_child(mesh_instance)
    var body := StaticBody3D.new()
    body.position = pos
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    add_child(body)

func _build_ground() -> void:
    _box(self, Vector3(180, 0.2, 180), Vector3(0, -0.15, 0), _material(Color(0.19, 0.27, 0.21)))

func _build_road() -> void:
    _box(self, Vector3(12, 0.08, 180), Vector3(0, -0.025, 0), _material(Color(0.12, 0.13, 0.15)))
    _box(self, Vector3(180, 0.08, 10), Vector3(0, -0.02, 0), _material(Color(0.12, 0.13, 0.15)))

func _build_city_blocks() -> void:
    var building_mat := _material(Color(0.42, 0.46, 0.51))
    var glass_mat := _material(Color(0.18, 0.35, 0.48))
    for x in [-45.0, -28.0, 25.0, 43.0]:
        for z in [-45.0, -25.0, 25.0, 45.0]:
            var h := 7.0 + float(abs(int(x + z)) % 5) * 2.5
            _box(self, Vector3(11, h, 11), Vector3(x, h / 2.0, z), glass_mat if h > 12.0 else building_mat)
