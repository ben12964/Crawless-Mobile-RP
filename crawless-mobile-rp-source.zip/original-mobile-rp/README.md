# Crawless Mobile RP — source repository

An original Android-first 3D roleplay game foundation inspired by Gold Russia / CRMP-style gameplay: Godot 4 client + authoritative Python/FastAPI backend + PostgreSQL.

## Important status
This is an implemented, runnable **development foundation**, not a finished production game or installable APK. It includes initial account/character APIs, persistent player state, inventory/economy routes, player report submission, a procedural 3D greybox scene, an initial HUD shell, and CI checks. It does not yet implement a multiplayer WebSocket session, admin report management, or a working virtual joystick. A production release still needs original art/audio, a designed city map, vehicle/animation assets, load/security testing, deployment secrets/infrastructure, Android SDK signing, and device QA.

## Architecture
- `client/`: Godot 4 project, procedural city block, third-person capsule placeholder, HUD shell, and API client. Keyboard input actions and a virtual joystick still need implementation.
- `server/`: FastAPI, JWT auth, SQLAlchemy models, PostgreSQL persistence, API routes, WebSocket session channel.
- `server/migrations/001_initial.sql`: explicit schema for deployment/review.
- `.github/workflows/ci.yml`: Python validation and headless Godot import when Godot is available.
- `docker-compose.yml`: local PostgreSQL + API.

## Validation status
- Python source files passed `compileall` syntax compilation during package inspection.
- Full API import/tests were not run in the inspection environment because the declared dependencies (including `pwdlib`) were not installed there. CI installs dependencies before running checks.
- Godot runtime/import validation was not run locally because the Godot executable was not available. The GitHub Actions Godot job must pass before treating the client as validated.

## Run backend locally
1. Install Docker and run `docker compose up --build`.
2. API docs: `http://localhost:8000/docs`
3. Health check: `http://localhost:8000/health`
4. Set `JWT_SECRET` to a long random secret before any public deployment.
5. Configure a real database and HTTPS/WSS before public testing.

## Open client
Open `client/project.godot` in Godot 4.3+ and run the project. Set `ApiClient.base_url` to your backend host. For a phone on the same Wi-Fi, use the computer/server LAN IP, not `localhost`.

## Android export
Install Godot's Android export templates and configure Android SDK/JDK in Godot Editor. Create a signing keystore for release builds; never commit signing secrets. This source package does not include an APK.

## Product decisions
This is a custom client/server game, not a drop-in client for arbitrary SA-MP hosting. SA-MP compatibility would require a separately engineered compatibility layer and is not promised here.
