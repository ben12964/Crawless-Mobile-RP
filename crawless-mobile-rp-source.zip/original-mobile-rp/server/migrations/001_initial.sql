-- PostgreSQL reference schema. Runtime models create these tables in development.
CREATE TABLE IF NOT EXISTS accounts (
  id SERIAL PRIMARY KEY, username VARCHAR(24) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL,
  is_banned BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS characters (
  id SERIAL PRIMARY KEY, account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  name VARCHAR(32) NOT NULL UNIQUE, model_id INTEGER NOT NULL DEFAULT 0, level INTEGER NOT NULL DEFAULT 1,
  cash BIGINT NOT NULL DEFAULT 500, bank BIGINT NOT NULL DEFAULT 2500, job VARCHAR(40) NOT NULL DEFAULT 'Unemployed',
  position JSONB NOT NULL DEFAULT '{"x":0,"y":1,"z":0}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS inventory_items (
  id SERIAL PRIMARY KEY, character_id INTEGER NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  item_key VARCHAR(48) NOT NULL, quantity INTEGER NOT NULL DEFAULT 1, metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  CONSTRAINT uq_character_item UNIQUE(character_id, item_key)
);
CREATE TABLE IF NOT EXISTS vehicles (
  id SERIAL PRIMARY KEY, owner_character_id INTEGER NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  model_key VARCHAR(48) NOT NULL, plate VARCHAR(12) NOT NULL UNIQUE,
  state JSONB NOT NULL DEFAULT '{"x":0,"y":0,"z":0,"fuel":100}'::jsonb, is_impounded BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE TABLE IF NOT EXISTS properties (
  id SERIAL PRIMARY KEY, owner_character_id INTEGER REFERENCES characters(id) ON DELETE SET NULL,
  property_key VARCHAR(64) NOT NULL UNIQUE, kind VARCHAR(24) NOT NULL, price BIGINT NOT NULL, data JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS reports (
  id SERIAL PRIMARY KEY, reporter_character_id INTEGER REFERENCES characters(id) ON DELETE SET NULL,
  category VARCHAR(24) NOT NULL DEFAULT 'player', subject VARCHAR(100) NOT NULL, body TEXT NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'open', assigned_admin VARCHAR(32), response TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY, actor_account_id INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
  action VARCHAR(48) NOT NULL, target_type VARCHAR(32) NOT NULL, target_id VARCHAR(64) NOT NULL,
  details JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_characters_account_id ON characters(account_id);
CREATE INDEX IF NOT EXISTS ix_inventory_character_id ON inventory_items(character_id);
CREATE INDEX IF NOT EXISTS ix_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS ix_audit_action ON audit_logs(action);
