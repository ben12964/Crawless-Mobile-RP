from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from .db import get_db
from .models import Account
from .security import decode_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

def current_account(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> Account:
    account_id = decode_token(token)
    account = db.get(Account, account_id)
    if not account or account.is_banned:
        raise HTTPException(status_code=401, detail="Account unavailable")
    return account
