from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .db import Base, engine
from .routes import auth, characters, game, reports

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Crawless Mobile RP API", version="0.1.0",
              description="Custom mobile roleplay game backend API")
origins = [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False,
                   allow_methods=["GET", "POST", "PATCH", "DELETE"], allow_headers=["Authorization", "Content-Type"])
app.include_router(auth.router); app.include_router(characters.router)
app.include_router(game.router); app.include_router(reports.router)

@app.get("/health", tags=["operations"])
def health():
    return {"status": "ok", "service": "crawless-mobile-rp-api"}
