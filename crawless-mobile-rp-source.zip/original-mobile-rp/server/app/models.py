from datetime import datetime, timezone
from sqlalchemy import String, Integer, BigInteger, Boolean, DateTime, ForeignKey, JSON, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

def now_utc():
    return datetime.now(timezone.utc)

class Account(Base):
    __tablename__ = "accounts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(24), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    characters: Mapped[list["Character"]] = relationship(back_populates="account", cascade="all, delete-orphan")

class Character(Base):
    __tablename__ = "characters"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(32), index=True)
    model_id: Mapped[int] = mapped_column(Integer, default=0)
    level: Mapped[int] = mapped_column(Integer, default=1)
    cash: Mapped[int] = mapped_column(BigInteger, default=500)
    bank: Mapped[int] = mapped_column(BigInteger, default=2500)
    job: Mapped[str] = mapped_column(String(40), default="Unemployed")
    position: Mapped[dict] = mapped_column(JSON, default=lambda: {"x": 0.0, "y": 1.0, "z": 0.0})
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    account: Mapped["Account"] = relationship(back_populates="characters")
    inventory: Mapped[list["InventoryItem"]] = relationship(back_populates="character", cascade="all, delete-orphan")
    __table_args__ = (UniqueConstraint("name", name="uq_character_name"),)

class InventoryItem(Base):
    __tablename__ = "inventory_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    character_id: Mapped[int] = mapped_column(ForeignKey("characters.id", ondelete="CASCADE"), index=True)
    item_key: Mapped[str] = mapped_column(String(48))
    quantity: Mapped[int] = mapped_column(Integer, default=1)
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    character: Mapped["Character"] = relationship(back_populates="inventory")
    __table_args__ = (UniqueConstraint("character_id", "item_key", name="uq_character_item"),)

class Vehicle(Base):
    __tablename__ = "vehicles"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    owner_character_id: Mapped[int] = mapped_column(ForeignKey("characters.id", ondelete="CASCADE"), index=True)
    model_key: Mapped[str] = mapped_column(String(48))
    plate: Mapped[str] = mapped_column(String(12), unique=True)
    state: Mapped[dict] = mapped_column(JSON, default=lambda: {"x": 0, "y": 0, "z": 0, "fuel": 100})
    is_impounded: Mapped[bool] = mapped_column(Boolean, default=False)

class Property(Base):
    __tablename__ = "properties"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    owner_character_id: Mapped[int | None] = mapped_column(ForeignKey("characters.id", ondelete="SET NULL"), nullable=True, index=True)
    property_key: Mapped[str] = mapped_column(String(64), unique=True)
    kind: Mapped[str] = mapped_column(String(24))
    price: Mapped[int] = mapped_column(BigInteger)
    data: Mapped[dict] = mapped_column(JSON, default=dict)

class Report(Base):
    __tablename__ = "reports"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    reporter_character_id: Mapped[int | None] = mapped_column(ForeignKey("characters.id", ondelete="SET NULL"), nullable=True)
    category: Mapped[str] = mapped_column(String(24), default="player")
    subject: Mapped[str] = mapped_column(String(100))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="open")
    assigned_admin: Mapped[str | None] = mapped_column(String(32), nullable=True)
    response: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_account_id: Mapped[int | None] = mapped_column(ForeignKey("accounts.id", ondelete="SET NULL"), nullable=True)
    action: Mapped[str] = mapped_column(String(48), index=True)
    target_type: Mapped[str] = mapped_column(String(32))
    target_id: Mapped[str] = mapped_column(String(64))
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
