from pydantic import BaseModel, Field, ConfigDict
from typing import Literal

class RegisterIn(BaseModel):
    username: str = Field(min_length=3, max_length=24, pattern=r"^[A-Za-z0-9_]+$")
    password: str = Field(min_length=10, max_length=128)

class LoginIn(BaseModel):
    username: str
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class CharacterCreate(BaseModel):
    name: str = Field(min_length=3, max_length=32, pattern=r"^[A-Za-z][A-Za-z_ ]+$")
    model_id: int = Field(default=0, ge=0, le=9999)

class CharacterOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    model_id: int
    level: int
    cash: int
    bank: int
    job: str
    position: dict

class ReportCreate(BaseModel):
    category: Literal["player", "bug", "admin", "other"] = "player"
    subject: str = Field(min_length=4, max_length=100)
    body: str = Field(min_length=10, max_length=3000)
    character_id: int | None = None

class ReportUpdate(BaseModel):
    status: Literal["open", "in_progress", "closed"]
    response: str | None = Field(default=None, max_length=3000)
    assigned_admin: str | None = Field(default=None, max_length=32)

class TransferIn(BaseModel):
    character_id: int
    amount: int = Field(gt=0, le=10_000_000)
