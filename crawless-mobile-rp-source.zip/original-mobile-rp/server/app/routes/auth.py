from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Account, AuditLog
from ..schemas import RegisterIn, LoginIn, TokenOut
from ..security import hash_password, verify_password, create_token

router = APIRouter(prefix="/auth", tags=["authentication"])

@router.post("/register", response_model=TokenOut, status_code=201)
def register(data: RegisterIn, db: Session = Depends(get_db)):
    username = data.username.strip()
    if db.query(Account).filter(Account.username.ilike(username)).first():
        raise HTTPException(409, "Username already exists")
    account = Account(username=username, password_hash=hash_password(data.password))
    db.add(account); db.flush()
    db.add(AuditLog(actor_account_id=account.id, action="account.register", target_type="account",
                    target_id=str(account.id), details={"username": username}))
    db.commit()
    return TokenOut(access_token=create_token(account.id))

@router.post("/login", response_model=TokenOut)
def login(data: LoginIn, db: Session = Depends(get_db)):
    account = db.query(Account).filter(Account.username.ilike(data.username.strip())).first()
    if not account or not verify_password(data.password, account.password_hash) or account.is_banned:
        raise HTTPException(401, "Invalid username or password")
    return TokenOut(access_token=create_token(account.id))
