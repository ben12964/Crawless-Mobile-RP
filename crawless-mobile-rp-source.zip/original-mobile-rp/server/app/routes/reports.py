from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..deps import current_account
from ..models import Account, Character, Report, AuditLog
from ..schemas import ReportCreate, ReportUpdate

router = APIRouter(prefix="/reports", tags=["player reports"])

@router.post("", status_code=201)
def create_report(data: ReportCreate, db: Session = Depends(get_db), account: Account = Depends(current_account)):
    if data.character_id is not None:
        c = db.query(Character).filter_by(id=data.character_id, account_id=account.id).first()
        if not c: raise HTTPException(404, "Character not found")
    report = Report(reporter_character_id=data.character_id, category=data.category,
                    subject=data.subject.strip(), body=data.body.strip())
    db.add(report); db.flush()
    db.add(AuditLog(actor_account_id=account.id, action="report.create", target_type="report",
                    target_id=str(report.id), details={"category": data.category}))
    db.commit()
    return {"id": report.id, "status": report.status, "created": True}

@router.get("/mine")
def mine(db: Session = Depends(get_db), account: Account = Depends(current_account)):
    chars = db.query(Character.id).filter_by(account_id=account.id).all()
    ids = [x[0] for x in chars]
    return [{"id": r.id, "category": r.category, "subject": r.subject, "body": r.body,
             "status": r.status, "response": r.response, "created_at": r.created_at}
            for r in db.query(Report).filter(Report.reporter_character_id.in_(ids)).order_by(Report.id.desc()).all()]
