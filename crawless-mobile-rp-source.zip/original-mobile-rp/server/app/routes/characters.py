from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..deps import current_account
from ..models import Account, Character, AuditLog
from ..schemas import CharacterCreate, CharacterOut

router = APIRouter(prefix="/characters", tags=["characters"])

@router.get("", response_model=list[CharacterOut])
def list_characters(db: Session = Depends(get_db), account: Account = Depends(current_account)):
    return db.query(Character).filter_by(account_id=account.id).order_by(Character.id).all()

@router.post("", response_model=CharacterOut, status_code=201)
def create_character(data: CharacterCreate, db: Session = Depends(get_db), account: Account = Depends(current_account)):
    if db.query(Character).filter(Character.account_id == account.id).count() >= 3:
        raise HTTPException(409, "Maximum 3 characters per account")
    name = " ".join(data.name.strip().split())
    if db.query(Character).filter(Character.name.ilike(name)).first():
        raise HTTPException(409, "Character name already exists")
    character = Character(account_id=account.id, name=name, model_id=data.model_id)
    db.add(character); db.flush()
    db.add(AuditLog(actor_account_id=account.id, action="character.create", target_type="character",
                    target_id=str(character.id), details={"name": name}))
    db.commit(); db.refresh(character)
    return character

@router.get("/{character_id}", response_model=CharacterOut)
def get_character(character_id: int, db: Session = Depends(get_db), account: Account = Depends(current_account)):
    character = db.query(Character).filter_by(id=character_id, account_id=account.id).first()
    if not character: raise HTTPException(404, "Character not found")
    return character
