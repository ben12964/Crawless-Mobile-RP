from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..deps import current_account
from ..models import Account, Character, InventoryItem, AuditLog
from ..schemas import TransferIn

router = APIRouter(prefix="/game", tags=["persistent game state"])

@router.get("/state/{character_id}")
def state(character_id: int, db: Session = Depends(get_db), account: Account = Depends(current_account)):
    c = db.query(Character).filter_by(id=character_id, account_id=account.id).first()
    if not c: raise HTTPException(404, "Character not found")
    items = db.query(InventoryItem).filter_by(character_id=c.id).all()
    return {"character": {"id": c.id, "name": c.name, "level": c.level, "cash": c.cash,
                          "bank": c.bank, "job": c.job, "position": c.position},
            "inventory": [{"key": i.item_key, "quantity": i.quantity, "metadata": i.metadata_json} for i in items]}

@router.post("/bank/deposit")
def deposit(data: TransferIn, db: Session = Depends(get_db), account: Account = Depends(current_account)):
    c = db.query(Character).filter_by(id=data.character_id, account_id=account.id).with_for_update().first()
    if not c: raise HTTPException(404, "Character not found")
    if c.cash < data.amount: raise HTTPException(400, "Insufficient cash")
    c.cash -= data.amount; c.bank += data.amount
    db.add(AuditLog(actor_account_id=account.id, action="bank.deposit", target_type="character",
                    target_id=str(c.id), details={"amount": data.amount}))
    db.commit()
    return {"cash": c.cash, "bank": c.bank}

@router.post("/bank/withdraw")
def withdraw(data: TransferIn, db: Session = Depends(get_db), account: Account = Depends(current_account)):
    c = db.query(Character).filter_by(id=data.character_id, account_id=account.id).with_for_update().first()
    if not c: raise HTTPException(404, "Character not found")
    if c.bank < data.amount: raise HTTPException(400, "Insufficient bank balance")
    c.bank -= data.amount; c.cash += data.amount
    db.add(AuditLog(actor_account_id=account.id, action="bank.withdraw", target_type="character",
                    target_id=str(c.id), details={"amount": data.amount}))
    db.commit()
    return {"cash": c.cash, "bank": c.bank}
