from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "sqlite:///./original_rp_dev.db"
    jwt_secret: str = "unsafe-local-development-secret-change-me"
    access_token_minutes: int = 60
    cors_origins: str = "http://localhost:8000"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
